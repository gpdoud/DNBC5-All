﻿#pragma once

#include <collection.h>
#include <ppltasks.h>

#include <TreeNode.h>
#include <ViewModel.h>
#include <TreeViewItem.h>
#include <TreeView.h>
#include <TreeViewItemAutomationPeer.h>
#include <IntegerToIndentationConverter.h>