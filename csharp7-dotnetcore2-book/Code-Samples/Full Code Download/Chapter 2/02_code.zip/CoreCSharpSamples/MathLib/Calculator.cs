﻿namespace MathLib
{
    public class Calculator
    {
        public static double Add(double x, double y) => x + y;

        public static double Subtract(double x, double y) => x - y;
    }
}
