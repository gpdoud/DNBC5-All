﻿using System;

namespace Wrox.HelloWorldApp
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Hello, World!");
        }
    }
}