﻿namespace FlowDocumentSample
{
    public class F1Results
    {
        public static string[][] Results =>
            new string[][]
            {
                new string[] { "1", "Lewis Hamilton", "GBR", "Mercedes", "363"},
                new string[] { "2", "Sebastian Vettel", "GER", "Ferrari", "317"},
                new string[] { "3", "Valtteri Bottas", "FIN", "Mercedes", "305"},
                new string[] { "4", "Kimi Räikkönen", "FIN", "Ferrari", "205"},
                new string[] { "5", "Daniel Riccardo", "AUS", "Red Bull Racing Tag Heuer", "200"},
                new string[] { "6", "Max Verstappen", "NED", "Red Bull Racing Tag Heuer", "168"},
                new string[] { "7", "Sergio Perez", "MEX", "Force India Mercedes", "100"},
                new string[] { "8", "Esteban Ocon", "FRA", "Force India Mercedes", "87"},
                new string[] { "9", "Carlos Sainz", "ESP", "Red Bull Racing Tag Heuer / Renault", "54"},
                new string[] { "10", "Nico Hulkenberg", "GER", "Renault", "43"}
            };
    }
}
