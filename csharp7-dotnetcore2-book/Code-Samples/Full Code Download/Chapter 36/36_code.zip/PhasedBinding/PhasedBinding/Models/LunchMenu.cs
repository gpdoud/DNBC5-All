﻿namespace PhasedBinding.Models
{
    public class LunchMenu
    {
        public int MenuId { get; set; }
        public string Text { get; set; }
        public string ImageUrl { get; set; }
    }
}
