﻿namespace CompiledBindingMethods.Models
{
    public class Person
    {
        public string GivenName { get; set; }
        public string Surname { get; set; }
    }
}
