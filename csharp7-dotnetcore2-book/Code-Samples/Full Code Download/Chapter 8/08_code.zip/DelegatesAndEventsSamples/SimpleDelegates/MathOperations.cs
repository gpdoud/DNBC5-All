﻿namespace Wrox.ProCSharp.Delegates
{
    class MathOperations
    {
        public static double MultiplyByTwo(double value) => value * 2;

        public static double Square(double value) => value * value;
    }
}