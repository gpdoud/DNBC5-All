﻿using System;

namespace Wrox.ProCSharp.Composition
{
    public class ImportEventArgs : EventArgs
    {
        public string StatusMessage { get; set; }
    }
}
