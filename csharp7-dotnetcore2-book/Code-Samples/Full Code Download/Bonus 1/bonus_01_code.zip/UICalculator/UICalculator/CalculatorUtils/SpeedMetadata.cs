﻿namespace Wrox.ProCSharp.Composition
{
    public enum Speed
    {
        Fast,
        Slow
    }

    public class SpeedMetadata
    {
        public Speed Speed { get; set; }
    }
}
