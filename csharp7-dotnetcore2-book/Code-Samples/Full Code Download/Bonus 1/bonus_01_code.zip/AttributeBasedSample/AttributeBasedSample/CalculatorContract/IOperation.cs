﻿namespace Wrox.ProCSharp.Composition
{
    public interface IOperation
    {
        string Name { get; }
        int NumberOperands { get; }
    }
}
