﻿using Windows.UI.Xaml.Controls;

namespace NavigationViewSample
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }
    }
}
