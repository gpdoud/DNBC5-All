﻿using Windows.UI.Xaml.Controls;

namespace MarkupExtensions
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();           
        }
    }
}
