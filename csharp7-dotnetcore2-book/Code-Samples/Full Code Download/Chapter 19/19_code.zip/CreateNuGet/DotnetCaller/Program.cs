﻿using System;
using SampleLib;

namespace DotnetCaller
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Demo.Show());
        }
    }
}
