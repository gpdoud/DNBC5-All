﻿using SharedProject;

namespace UsingASharedProject
{
    class Program
    {
        static void Main()
        {
            Message.Show(".NET Core");
        }
    }
}
