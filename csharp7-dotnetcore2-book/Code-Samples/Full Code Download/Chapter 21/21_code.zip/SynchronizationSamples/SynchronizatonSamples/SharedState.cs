﻿namespace SynchronizatonSamples
{
    public class SharedState
    {
        public int State { get; set; }
    }

}
