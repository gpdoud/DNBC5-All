# Readme - Code Samples for Bonus Chapter 4, Bots and Cognitive Services

This chapter contains the following code samples:

* DialogBotSample
* LUISBotSample

The code samples are based on the .NET Framework - because at the time of this writing the Bot Framework SDK is not yet available for .NET Core. Check the [GitHub repository](https://github.com/ProfessionalCSharp) for updates.

The samples of this chapter need Visual Studio 2017 Update 5 and an Microsoft Azure account. Read the book chapter for more information.
 
For code comments and issues please check [Professional C#'s GitHub Repository](https://github.com/ProfessionalCSharp/ProfessionalCSharp7)

Please check my blog [csharp.christiannagel.com](https://csharp.christiannagel.com "csharp.christiannagel.com") for additional information for topics covered in the book.

Thank you!