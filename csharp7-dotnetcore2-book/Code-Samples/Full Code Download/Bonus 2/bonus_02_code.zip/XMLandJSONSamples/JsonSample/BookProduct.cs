﻿namespace JsonSample
{
    public class BookProduct : Product
    {
        public string ISBN { get; set; }
    }
}
