﻿namespace WithDI
{
    public interface IGreetingService
    {
        string Greet(string name);
    }
}