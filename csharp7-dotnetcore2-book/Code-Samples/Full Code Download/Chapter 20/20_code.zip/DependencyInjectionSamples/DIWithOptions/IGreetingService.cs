﻿namespace DIWithOptions
{
    public interface IGreetingService
    {
        string Greet(string name);
    }
}