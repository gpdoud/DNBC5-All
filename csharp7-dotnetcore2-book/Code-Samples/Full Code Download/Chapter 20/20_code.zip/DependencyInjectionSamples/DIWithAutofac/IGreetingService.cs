﻿namespace DIWithAutofac
{
    public interface IGreetingService
    {
        string Greet(string name);
    }
}