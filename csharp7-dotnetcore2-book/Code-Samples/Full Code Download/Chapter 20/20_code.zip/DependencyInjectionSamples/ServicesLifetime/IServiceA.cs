﻿namespace ServicesLifetime
{
    public interface IServiceA
    {
        void A();
    }
}
