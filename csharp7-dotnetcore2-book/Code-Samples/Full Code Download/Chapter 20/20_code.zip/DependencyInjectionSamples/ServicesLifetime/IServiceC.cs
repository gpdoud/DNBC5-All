﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ServicesLifetime
{
    public interface IServiceC
    {
        void C();
    }
}
