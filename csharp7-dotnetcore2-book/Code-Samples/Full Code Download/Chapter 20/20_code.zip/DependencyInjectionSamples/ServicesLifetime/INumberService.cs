﻿namespace ServicesLifetime
{
    public interface INumberService
    {
        int GetNumber();
    }
}
