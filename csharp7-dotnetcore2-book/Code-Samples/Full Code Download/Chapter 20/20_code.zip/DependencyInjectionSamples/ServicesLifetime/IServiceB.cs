﻿namespace ServicesLifetime
{
    public interface IServiceB
    {
        void B();
    }
}
