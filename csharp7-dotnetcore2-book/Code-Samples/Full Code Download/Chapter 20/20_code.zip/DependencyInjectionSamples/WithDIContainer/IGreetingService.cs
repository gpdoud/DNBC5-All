﻿namespace WithDIContainer
{
    public interface IGreetingService
    {
        string Greet(string name);
    }
}