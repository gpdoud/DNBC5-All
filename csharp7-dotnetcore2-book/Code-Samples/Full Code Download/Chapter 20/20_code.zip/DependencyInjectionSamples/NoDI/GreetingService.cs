﻿namespace NoDI
{
    public class GreetingService
    {
        public string Greet(string name) => $"Hello, {name}";
    }
}
