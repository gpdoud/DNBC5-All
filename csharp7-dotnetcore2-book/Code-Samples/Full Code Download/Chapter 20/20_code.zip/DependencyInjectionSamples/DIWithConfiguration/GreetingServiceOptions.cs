﻿namespace DIWithConfiguration
{
    public class GreetingServiceOptions
    {
        public string From { get; set; }
    }
}
