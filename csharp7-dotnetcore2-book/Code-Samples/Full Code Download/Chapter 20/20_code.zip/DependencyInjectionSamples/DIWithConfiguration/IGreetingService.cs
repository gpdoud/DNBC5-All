﻿namespace DIWithConfiguration
{
    public interface IGreetingService
    {
        string Greet(string name);
    }
}