﻿using Xamarin.Forms;

namespace XamarinClient
{
    public class PageService : IPageService
    {
        public Page Page { get; set; }
    }
}
