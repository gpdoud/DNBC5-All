﻿using Xamarin.Forms;

namespace XamarinClient
{
    public interface IPageService
    {
        Page Page { get; set; }
    }
}