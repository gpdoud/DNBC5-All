﻿namespace LoggingSample
{
    class LoggingEvents
    {
        public const int Injection = 2000;
        public const int Networking = 2002;
    }
}
