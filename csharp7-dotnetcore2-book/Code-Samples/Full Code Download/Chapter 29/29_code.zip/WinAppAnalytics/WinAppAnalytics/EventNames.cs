﻿namespace WinAppAnalytics
{
    public class EventNames
    {
        public const string ButtonClicked = nameof(ButtonClicked);
        public const string PageNavigation = nameof(PageNavigation);
        public const string CreateMenu = nameof(CreateMenu);
    }
}
