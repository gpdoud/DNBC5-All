﻿namespace BooksAppX
{
    internal class AboutPageViewModel
    {
    }
}