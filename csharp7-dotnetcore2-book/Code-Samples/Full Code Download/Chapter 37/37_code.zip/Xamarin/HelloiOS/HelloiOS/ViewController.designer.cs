﻿// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;

namespace HelloiOS
{
    [Register ("ViewController")]
    partial class ViewController
    {
        [Action ("OnButtonClick:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void OnButtonClick (UIKit.UIButton sender);

        void ReleaseDesignerOutlets ()
        {
        }
    }
}