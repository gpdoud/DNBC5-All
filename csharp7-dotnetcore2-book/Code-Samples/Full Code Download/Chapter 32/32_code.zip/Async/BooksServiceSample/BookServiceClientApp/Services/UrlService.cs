﻿namespace BookServiceClientApp.Services
{
    public class UrlService
    {
        public string BaseAddress => "http://localhost:1079/";
        public string BooksApi => "api/BookChapters/";
    }
}
