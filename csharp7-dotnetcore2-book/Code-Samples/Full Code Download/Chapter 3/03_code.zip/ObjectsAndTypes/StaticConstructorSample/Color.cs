﻿namespace StaticConstructorSample
{
    public enum Color
    {
        White,
        Red,
        Green,
        Blue,
        Black
    }
}