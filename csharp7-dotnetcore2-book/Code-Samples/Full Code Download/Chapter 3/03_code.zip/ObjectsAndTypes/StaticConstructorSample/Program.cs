﻿using System;

namespace StaticConstructorSample
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine($"User-preferences: BackColor is: {UserPreferences.BackColor}");
        }
    }
}
