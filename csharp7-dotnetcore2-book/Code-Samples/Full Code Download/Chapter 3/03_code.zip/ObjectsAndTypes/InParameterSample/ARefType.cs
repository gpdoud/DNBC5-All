﻿namespace InParameterSample
{
    public class ARefType
    {
        public int Data { get; set; }
    }
}
