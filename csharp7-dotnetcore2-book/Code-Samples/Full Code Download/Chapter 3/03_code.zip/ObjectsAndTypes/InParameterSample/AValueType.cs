﻿namespace InParameterSample
{
    struct AValueType
    {
        public int Data;
    }
}
