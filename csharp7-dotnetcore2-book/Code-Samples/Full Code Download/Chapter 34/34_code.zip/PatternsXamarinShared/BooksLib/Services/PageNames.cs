﻿namespace BooksLib.Services
{
    public class PageNames
    {
        public const string BooksPage = nameof(BooksPage);
        public const string BookDetailPage = nameof(BookDetailPage);
    }
}
