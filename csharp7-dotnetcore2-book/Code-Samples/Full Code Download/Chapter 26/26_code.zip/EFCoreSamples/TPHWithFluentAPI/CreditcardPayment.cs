﻿namespace TPHWithFluentAPI
{
    public class CreditcardPayment : Payment
    {
        public string CreditcardNumber { get; set; }
    }
}
