﻿namespace TPHWithFluentAPI
{
    public class CashPayment : Payment
    {
    }
}
