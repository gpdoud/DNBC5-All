﻿namespace OwnedEntities
{
    public class Location
    {
        public string Country { get; set; }
        public string City { get; set; }
    }
}
