﻿namespace ConflictHandlingSample
{
    public class Book
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public string Publisher { get; set; }
        public byte[] TimeStamp { get; set; }
    }
}
